# garbage-incident-reports-management
Garbage Incident report management application in PHP with Google Maps integration.
