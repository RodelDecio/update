<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Waste Management System</title>
<link rel="stylesheet" href="css/styles.css" type="text/css">
 <!-- Google Fonts -->
 <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

 <!-- Vendor CSS Files -->
 <link href="vendor/aos/aos.css" rel="stylesheet">
 <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 <link href="vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
 <link href="vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
 <link href="vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
 <link href="vendor/remixicon/remixicon.css" rel="stylesheet">
 <link href="vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

</head>
<body>

  <header id="header" class="fixed-top ">
  <div class="container d-flex align-items-center">
  </div>
  <nav class="nav" class="navbar">
    <div class="nav-left">
      <a href="index.php" class="right">
        <img src="images/logo.png" alt="" class="right" width="80" height="80">
      </a>
    </div>
    <ul class="right">
      <li><a class="nav-link scrollto active" href="#home"><span class="fa fa-home"> Home</span></a></li>
      <li><a class="nav-link scrollto" href="#services"><span class="fa fa-truck" > Our Services</span></a></li>
      <li><a class="nav-link scrollto" href="#about"><span class="fa fa-info-circle" > About Us</span></a></li>
      <li><a class="nav-link scrollto" href="login.php"><span class="fa fa-user"> Login</span></a></li>
      <li><a class="nav-link scrollto" href="register.php"><span class="fa fa-plus-square"> Register</a></li>
    </ul>
    <i class="bi bi-list mobile-nav-toggle"></i>
  </nav>
</div>
</header>



  <!-- ======= Home Section ======= -->
  <section id="home" class="d-flex align-items-center">
    <video autoplay muted loop id="home-video">
      <source src="images/0510.mp4" type="video/mp4">
    </video>
    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1">
          <h1>Enhance Environmental Sustainability in Barangay 177, Caloocan City!</h1>
          <h2>Reduce Waste, Protect Our Environment!</h2>
        </div>
      </div>
    </div>
  </section><!-- End Home -->
<!-- ======= Our Services Section ======= -->
<section id="services" class="d-flex align-items-center">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="section-title">
          <h2>Our Services</h2>
        </div>
        <p>
          We offer a range of services aimed at improving waste management and promoting environmental sustainability within Barangay 177, Caloocan City. Our services include:
        </p>
        <ul>
          <li>Waste Reporting: Residents can easily report waste or garbage issues in their neighborhood through our user-friendly web interface. With just a few clicks, they can submit their concerns directly to the relevant municipal authorities.</li>
          <li>Real-Time Tracking: Our platform allows users to track the status of their complaints in real-time. They can monitor the progress of their reports and check whether the reported issue has been addressed by the municipality.</li>
          <li>Environmental Education: Users can explore various ideas and initiatives related to waste recycling and management through our website. We aim to promote environmental awareness and encourage sustainable practices within Barangay 177.</li>
        </ul>
      </div>
      <div class="col-lg-6">
        <p>
          Our services are designed to be user-friendly and accessible to residents of all ages and technical abilities. Whether using a desktop computer or a handheld device with internet access, users can easily navigate the platform to utilize our services.
        </p>
        <p>
          Upon submission, complaints are automatically routed to the relevant municipal authorities responsible for waste management in Barangay 177, ensuring efficient handling and timely response to reported issues.
        </p>
        <p>
          Barangay administrators have the capability to acknowledge received reports, providing transparency and assurance to residents that their concerns are being addressed.
        </p>
        <p>
          Through the Waste Management System, residents of Barangay 177 can actively participate in keeping their community clean and sustainable. By leveraging technology and collaboration, we strive to create a healthier environment and enhance the quality of life for all residents.
        </p>
        <p>
          Ready to make a positive impact in Barangay 177, Caloocan City? Sign up for an account on our platform and start utilizing our services today. Together, we can work towards a cleaner, greener future for our community.
        </p>
      </div>
    </div>
  </div>
</section>
<!-- End Our Services Section -->


<main id="main">


    <!-- ======= About Us Section ======= -->
    <section id="about" class="d-flex align-items-center">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="section-title">
              <h2>About Us</h2>
            </div>
            <p>
              The Waste Management System is an innovative web and mobile-based application designed to facilitate the reporting of waste-related concerns to municipal authorities, particularly in Barangay 177, Caloocan City. Our platform offers a digital solution for residents to easily submit complaints regarding waste or garbage issues in their neighborhood, streamlining the process for a cleaner, more sustainable community.
            </p>
            <ul>
              <li>Residents of Barangay 177 can conveniently report waste or garbage problems near their locality through our user-friendly web interface. With just a few clicks, they can submit their concerns directly to the relevant municipal authorities.</li>
              <li>Our platform allows users to track the status of their complaints in real-time. They can easily monitor the progress of their reports and check whether the reported issue has been addressed by the municipality.</li>
              <li>Users can explore various ideas and initiatives related to waste recycling and management through our website. We aim to promote environmental awareness and encourage sustainable practices within Barangay 177.</li>
            </ul>
          </div>
          <div class="col-lg-6">
            <p>
              Our web application is designed to be user-friendly, accessible to residents of all ages and technical abilities. Whether using a desktop computer or a handheld device with internet access, users can easily navigate the platform to report their concerns.
            </p>
            <p>
              Upon submission, complaints are automatically routed to the relevant municipal authorities responsible for waste management in Barangay 177. This ensures efficient handling and timely response to reported issues.
            </p>
            <p>
              Barangay administrators have the capability to acknowledge received reports, providing transparency and assurance to residents that their concerns are being addressed.
            </p>
            <p>
              The Waste Management System empowers residents of Barangay 177 to actively participate in keeping their community clean and sustainable. By leveraging technology and collaboration, we strive to create a healthier environment and enhance the quality of life for all residents.
            </p>
            <p>
              Ready to make a positive impact in Barangay 177, Caloocan City? Sign up for an account on our platform and start reporting waste-related issues with ease. Together, we can work towards a cleaner, greener future for our community.
            </p>
          </div>
        </div>
      </div>
    </section>
    <!-- End About Us Section -->
 <!-- ======= Footer ======= -->
 <footer id="footer">


  <div class="footer-top">
    <div class="container">
      <div class="row">

        <div class="col-lg-3 col-md-6 footer-contact">
          <h3><img src="images/logo.png" style="width:150px;height:130px;"></h3><br>
          <p><a href="#" class="phone"><i class="bi bi-geo-alt"></i></a>
            Barangay 177,
            <br> City of Caloocan,<br>Philippines.</p> 
        </div>

        <div class="col-lg-3 col-md-6 footer-contact">
          <h4>Contact Us</h4>
          <p><a class="phone"><i class="bi bi-phone"></i></a> <strong>Phone:</strong> +63 1234567890</p><br>
          <p><a class="phone"><i class="bi bi-telephone"></i></a> <strong>HotLine:</strong> +63 1234567890</p><br>
          <p><a class="phone"><i class="bi bi-envelope"></i></a> <strong>Email:</strong> <a href="https://caloocancity.gov.ph/">caloocancity@gmail.com</p><br>
<br><br></a>  
        </div>

        <div class="col-lg-3 col-md-6 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><a href="#" class="phone"><i class="bi bi-house "></i></a></i> <a href="#">  Home</a></li>
            <li><a href="#" class="phone"><i class="bi bi-truck "></i></a></i> <a href="#services">  Our Services</a></li>
            <li><a href="#" class="phone"><i class="bi bi-info-circle "></i></a></i> <a href="#about">  About us</a></li>
            <li><a href="#" class="phone"><i class="bi bi-person "></i></a></i> <a href="login.php">  LogIn</a></li>
            <li><a href="#" class="phone"><i class="bi bi-person-plus "></i></a></i> <a href="register.php">  Register</a></li>

            
          </ul>
        </div>



        <div class="col-lg-3 col-md-6 footer-links">
          <h4>Our Social Networks</h4>
          <p>Follow us in our social media to stay updated about community waste management.</p>
          <div class="social-links mt-3">
            <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
            <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
            <a href="#" class="youtube"><i class="bx bxl-youtube"></i></a>
            <a href="#" class="twitter">
              <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" class="bi bi-twitter-x" viewBox="0 0 16 16">
                <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865z"/>
              </svg>
            </a>
            <a href="#" class="youtube"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-tiktok" viewBox="0 0 16 16">
              <path d="M9 0h1.98c.144.715.54 1.617 1.235 2.512C12.895 3.389 13.797 4 15 4v2c-1.753 0-3.07-.814-4-1.829V11a5 5 0 1 1-5-5v2a3 3 0 1 0 3 3z"/>
            </svg></i></a>
            
          </div>
        </div>

      </div>
    </div>
  </div>
</main>
</footer>
  <div class="footer">
    &copy; Copyright <strong><span>WasteManagementSystem</span></strong>. All Rights Reserved
  </div>

</body>
</html>
